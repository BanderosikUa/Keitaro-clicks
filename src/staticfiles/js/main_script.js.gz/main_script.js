$(document).ready(function()
{
    $(function () {
        $('#datepicker, #datepicker2').datepicker();
    });
})